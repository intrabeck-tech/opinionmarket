---
name: Python bot publishing
description: Replit artifact registration needed for publishing a root-level Python long-polling bot
---

In a pnpm workspace, a root-level Python bot is not recognized by Publishing from `.replit` deployment settings alone. It needs a registered deployable artifact with a production service whose run command points to the real Python entry point.

**Why:** The workspace had a working root bot and VM settings but Publishing still reported only design mockups and reusable libraries until a deployable bot artifact was registered.

**How to apply:** Keep the bot source and secure secret unchanged, register a deployable application artifact, and configure its production build/run manifest to use `python main.py`; use Reserved VM for continuous long polling.

For production, install from the locked Python project environment before launch and run through that environment rather than relying on the development-only interpreter path.

**Why:** The development workflow's interpreter setup is not the same guarantee as the publishing build environment; installing from `uv.lock` makes the Telegram dependency available before the VM starts.

**How to apply:** Use `uv sync --frozen` in the artifact production build and `uv run python main.py` as the production process.