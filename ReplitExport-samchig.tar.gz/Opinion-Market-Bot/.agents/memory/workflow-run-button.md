---
name: Telegram bot workflow startup
description: Replit workflow naming and Run-button behavior for console-only long-polling services
---

Use a descriptive workflow name and point the Run button directly at that workflow when running a console-only Telegram bot. The reserved `Project` name is rejected by the workflow manager, and a stale wrapper can leave the visible start action waiting even when the child process is healthy.

**Why:** The bot process was healthy, but the Run button referenced a non-existent reserved wrapper; replacing it with a direct bot runner resolved the misleading “Starting” state.

**How to apply:** Configure one descriptive console workflow with the direct Python command, set the Run button to that name through validated `.replit` configuration, and verify the workflow logs show `Application started`.