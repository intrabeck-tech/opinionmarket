# OpinionMarket Telegram Bot

Telegram bot that welcomes users and opens the OpinionMarket web app as a Telegram Mini App.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `python main.py` — run the Telegram bot with the secure `BOT_TOKEN` secret
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Bot: Python 3.11 + `python-telegram-bot`

## Where things live

- `main.py` — Telegram bot handlers and Mini App launch button
- `pyproject.toml` / `uv.lock` — Python dependency manifest and lockfile
- `BOT_TOKEN` — required secure environment secret; never hard-code this value

## Architecture decisions

- The bot uses Telegram long polling so it can run without a public webhook endpoint.
- The OpinionMarket button uses Telegram's `WebAppInfo`, which opens the site as a Mini App inside Telegram.

## Product

- `/start` sends a welcome message and a single “🚀 Open OpinionMarket” button.

## User preferences

- Keep the Telegram bot token in the `BOT_TOKEN` secret only.

## Gotchas

- The bot exits with a clear error if `BOT_TOKEN` is missing.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
